----- Mega Hacker -----
warning /!\
dont Edit in the script
-----------------------
you should be installed :
python
python2
------------------------ 
and good luck
